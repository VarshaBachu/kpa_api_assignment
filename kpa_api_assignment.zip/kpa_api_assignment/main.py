from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import engine, SessionLocal
import models, schemas

models.Base.metadata.create_all(bind=engine)
app = FastAPI(title="KPA Form Data API")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/api/v1/form", response_model=schemas.FormResponse)
def create_form(form: schemas.FormCreate, db: Session = Depends(get_db)):
    new_form = models.FormData(**form.dict())
    db.add(new_form)
    db.commit()
    db.refresh(new_form)
    return new_form

@app.get("/api/v1/form/{form_id}", response_model=schemas.FormResponse)
def get_form(form_id: int, db: Session = Depends(get_db)):
    form = db.query(models.FormData).filter(models.FormData.id == form_id).first()
    if not form:
        raise HTTPException(status_code=404, detail="Form not found")
    return form
