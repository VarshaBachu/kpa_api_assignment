from pydantic import BaseModel, EmailStr
from datetime import datetime

class FormCreate(BaseModel):
    name: str
    phone_number: str
    email: EmailStr
    address: str = None

class FormResponse(BaseModel):
    id: int
    name: str
    phone_number: str
    email: EmailStr
    address: str = None
    created_at: datetime

    class Config:
        orm_mode = True
