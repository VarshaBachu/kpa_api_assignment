# KPA API Assignment

## Overview
Implements two backend APIs from the KPA Form Data specification using FastAPI and PostgreSQL.

- POST /api/v1/form
- GET /api/v1/form/{id}

## Setup Instructions
1. Clone repo and install requirements.
2. Configure `.env` using `.env.example`.
3. Create PostgreSQL database `kpa_db`.
4. Run server:
   ```bash
   uvicorn main:app --reload
   ```
5. Test via Swagger UI: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).
